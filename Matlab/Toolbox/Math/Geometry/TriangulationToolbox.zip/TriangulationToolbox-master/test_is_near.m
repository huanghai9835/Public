function [result] = test_is_near(a, b, tol, verbose)
%TEST_IS_TRUE  Check whether two given values are near or not
%
%   RESULT = TEST_IS_NEAR(A, B, TOL, VERBOSE)
%       (matrix) A      : The 1st given value
%       (matrix) B      : The 2nd given value
%       (scalar) TOL    : Tolerance (default: 1.0e-8)
%       (scalar) VERBOSE: A flag to print its result (default: true)
%       (scalar) RESULT : The test result
%
%   Note: Two values, A and B, should be same size.
%
%   Example:
%       t = test_is_near(4.17, 4.19, 0.1)
%       t = test_is_near(pi, pi + eps)
%       t = test_is_near([3, 29], [3 + eps, 29 - eps])
%
%   See also test_is_true.

if nargin < 3
    tol = 1e-8;
end
if nargin < 4
    verbose = true;
end

if isequal(abs(a - b) < tol, ones(size(a)))
    result = true;
    if verbose, fprintf(1, 'true\n'); end
else
    result = false;
    if verbose, fprintf(2, 'false\n'); end
end
